clear all;
clc;
close all;
ma=load('Shepp-Logan_3d_256.mat'); 
figure,plot3(ma)